const BASE_URL = "https://bit.io/";

const PORT_API_LISTEN = 3000;

const BASE_URL_API = `http://localhost:${PORT_API_LISTEN}`;

module.exports = {
  BASE_URL,
  BASE_URL_API,
  PORT_API_LISTEN
};