module.exports = {
  testEnvironment: "node",
};
