##### RUN PROJECT
---
###### 🧩  Install packages

```
$ yarn install
```

###### 🏃🏽‍♂️  Start project

```
$ yarn start
```

###### 💻  See in terminal console the result